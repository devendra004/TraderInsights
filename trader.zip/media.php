<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Media | TraderInsights</title>
   <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">

  <link href="css/hr.css" rel="stylesheet">
<!--<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>-->
   
   <link href="Media%20_%20TraderInsights_files/footer_font.htm" rel="stylesheet">
  
  <link href="css/css.css" rel="stylesheet" type="text/css">
 <link rel="stylesheet" type="text/css" href="css/bootstrap-glyphicons.css"> 
  <link rel="stylesheet" href="css/font-awesome.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/media.css">
  </head>
  <body>
  <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.5";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
 

  <?php include('header.php');?> 
<div class="media-banner inner-banner">
   
  <div class="container">
    <div class="row">
      
      <h1 class="banner-header">TraderInsight makes it easy for anyone to get access to world-class,
       long-term and short-term investment research without the high fees or
       management fees</h1>
    </div>
  </div>    

</div>

<div class="bspacer"></div>
 <div class="container">
      <div class="row">
      <div class="col-sm-6">
<div class="fb-page" data-href="https://www.facebook.com/TraderInsight-864728870271353/" data-tabs="timeline" data-width="550" data-height="600" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
</div>

<div class="col-sm-6">
<a class="twitter-timeline" href="https://twitter.com/TraderInsightUK" data-widget-id="677042356139397120">Tweets by @TraderInsightUK</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
</div>
</div>
</div>

<div class="bspacer"></div>

<section class="grid">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6 belief">
        <a href="#">
          <h6>Learn More</h6>
          <h2>Our Belief</h2>
        </a>
      </div>
      <div class="col-sm-6 fee">
        <a href="#">
          <h6>Learn More</h6>
          <h2>Our Low Fees</h2>
        </a>
      </div>
    </div>
  </div>
</section>








<?php include('footer.php');?>

</body></html>