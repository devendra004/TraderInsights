<header>
  <div class="container " style="display:table">   
      <div class="row top-menu">
    <h5 class="pull-left">
     <i class="fa fa-phone-square"></i> 020-3751-8290 | <i class="fa fa-envelope"></i> 
     <a href="mailto:admin@eca-strategies.com">support@traderinsight.co.uk </a>
    </h5>
      <div class="pull-right">
        <ul>
          <li><a href="terms.php">Terms of Use</a></li>
          <li><a href="#contact">Contact Us</a></li>
        </ul>
      </div>
  </div>
 </div>
</header>
  <nav class="navbar ">
     
    <div class="container">
      <div class="row">
  
        <button data-toggle="collapse" class="navbar-toggle" data-target="#navbar">
            <span color class="icon-bar"><i class="fa fa-bars"></i></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
          <div class="navbar-brand " style="padding:0; margin-top:-7px;">
         <!--   <span class="logo">Trader<span style="color:#1ba2dc">Insight</span></span> -->

         <a href="index.php"> <img src="images/trader-insight.png" alt="" title="Trader Insight" / width="220"> </a>
          </div>
    
            <div  class="collapse navbar-collapse hvr-underline-reveal" id="navbar">
              <ul class=" nav navbar-nav navbar-right tmargin30 ">
          
                 <li class=" "><a href="index.php">Home</a></li>
        
                 <li ><a href="about-us.php">About Us</a></li>

             <!--    <li ><a  href="#">Explore TraderInsight</a></li>
                
                 <li><a class="active" href="#">How it Works</a></li>
                 
                 <li ><a  href="#">Resources</a></li>   -->
                 <li><a  href="packages.php">Packages</a></li>
                 <li><a href="what_we_do.php">What We Do</a> </li>
                 <li ><a  href="media.php">Media</a></li> 
                 
                <li><a href="faq.php">FAQ</a> </li>
       
               </ul>              
            </div>
      </div>
    </div>
  </nav>




  <div class="sticky-container">
    <ul class="sticky">
      <a target="_blank" href="https://www.facebook.com/TraderInsight-864728870271353/">
        <li>
        <img width="32" height="32" title="" alt="" src="images/fb1.png" />
        <p>Facebook</p>
      </li></a>

      <a target="_blank" href="https://twitter.com/traderinsightuk">
        <li>
        <img width="32" height="32" title="" alt="" src="images/tw1.png" />
        <p>Twitter</p>
      </li></a>
     <a target="_blank" href="https://www.instagram.com/traderinsightuk/">
      <li>
        <img width="32" height="32" title="" alt="" src="images/inst1.png" />
        <p>Instagram</p>
      </li></a>
      
    </ul>
  </div>