
<footer>
	<div class="container footer_contain pad_both_50">
		<div class="row padb_20">
			<div class="col-lg-8 col-lg-offset-2">
				<h3 class="text-center footer_heading">Risk warning</h3>
				<p class="text-center">
					This site cannot substitute for professional investment advice or independent factual verification. To us it your must accept our terms of use, privacy and disclaimer policies
	</p>

					<p class="text-center">We are an educational forum for analysing, learning & discussing general and generic information related to stocks, investments and strategies. TraderInsight is not a broker/dealer, or investment advisors.
					</p>
				</div>
			</div>
			<div class="row padb_20">
			<div class="col-lg-10 col-lg-offset-1">
				<div class="col-lg-2">
					<div class="footer_list">

						<ul>
						<div class="li_heading padb_20">
						<h3 class=""> TraderInsight </h3>
						</div>
							<li class=" "><a href="index.php">Home</a></li>
							 <li ><a href="about-us.php">About Us</a></li>
								<li><a href="what_we_do.php">What We Do </a></li>
								<li><a  href="packages.php">Packages</a></li>
								<li><a  href="media.php">Media</a> </li>
								<li><a href="faq.php">F&Qs</a> </li>	
							</ul>
						</div>
					</div>
					<div class="col-lg-4">
            
					<div class="footer_list">
                           
						<ul>
						<div class="li_heading padb_20">
						<h3 style="visibility:hidden;">fdfdfdf</h3>
						</div >
						<div class="icons">
							<li>
								<i class=" fa fa-eye"></i>Not Regulated by the FCA

							</li>
							
							<li><i class="fa fa-institution"></i>We are partnered with a range of market professionals </li>
							<li><i class="fa fa-lock"></i>Protected by SSL Certificate </li>
							</div>
							</ul>
					</div>
					</div>
					<div class="col-lg-3">
					<div class="footer_list">
                           
						<ul>
						<div class="li_heading padb_20">
						<h3 >Support</h3>
						</div>
							<li><a href="faq.php">F&Qs</a> </li>
							
							<li>  Support@traderinsight.co.uk</li>
							<li> Customer Support </li>
							<li>0203 751 8289</li>
							<li>Customer support</li>
							<li> Office </li>
							<li>0203 751 8290</li>
							
							
							</ul>
					</div>
  
   

					</div>
					<div class="col-lg-3">
						<div class="footer_list">
                           
						<ul>
						<div class="li_heading padb_20">
						<h3 >Keep in touch</h3>
						</div>
						<div class="social">
						<li class="padb_20">
							<a href="https://www.facebook.com/TraderInsight-864728870271353/" target="_blank"><i class="fa fa-facebook"></i></a>
							<a href="https://twitter.com/traderinsightuk" target="_blank"><i class="fa fa-twitter"></i></a>
							<a href="https://www.instagram.com/traderinsightuk/" target="_blank"><i class="fa fa-instagram"></i></a>
							
						</li>
							
							</div>
							<li>
								43 Manchester Street
								London
								W1U 7LP
							</li>
	
							</ul>
					</div>
					</div>

					</div>
				</div>
				<div class="row padb_20">
					<div class="col-lg-12 conditions">
						<p class="text-center">




							<a href="terms.php#tab_default_1">Terms and Conditions</a>
							<a href="terms.php#tab_default_2">Disclaimer</a>
							<a href="terms.php#tab_default_3">Privacy Policy</a>
							<a href="terms.php#tab_default_4">Cookies </a>
						</p>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-lg-offset-3 ">
						<p class="text-center " style="font-size:14px;">

							
TraderInsight is a trading style of Commodity Index Limited. Registered in England and Wales, Company registration number: 8999448 with a registered office at 43 Manchester Street, London, W1U 7LP

						</p>
					</div>
				</div>
			</div>
		</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
            <script>
              new WOW().init();
                  $(function(){
    $(".dropdown").hover(            
            function() {
                $('.dropdown-menu', this).stop( true, true ).addClass('animated fadeInLeft');
                $(this).toggleClass('open');
                $('b', this).toggleClass("caret caret-up");                
            },
            function() {
                $('.dropdown-menu', this).stop( true, true ).removeClass('animated fadeInLeft');
                $(this).toggleClass('open');
                $('b', this).toggleClass("caret caret-up");                
            });
   


         
                $(".custom_btn1").click(function() {
                  
                  $('html, body').animate({
                    scrollTop: $(".form").offset().top
                  }, 1000);
                });
    $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });

              });
            </script> 
<script type="text/javascript">
        $(function() {
      $('#carousel').carouFredSel({
        width: '100%',
        items: {
          visible: 3,
          start: -1
        },
        scroll: {
          items: 1,
          duration: 1000,
          timeoutDuration: 3000
        },
        prev: '#prev',
        next: '#next',
        pagination: {
          container: '#pager',
          deviation: 1
        }
      });
    });
  </script> 
  <script type="text/javascript" src="js/jquery.carouFredSel-6.0.4-packed.js"></script>